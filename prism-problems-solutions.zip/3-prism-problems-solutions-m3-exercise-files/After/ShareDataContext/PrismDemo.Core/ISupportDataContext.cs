﻿namespace PrismDemo.Core
{
    public interface ISupportDataContext
    {
        object DataContext { get; set; }
    }
}
